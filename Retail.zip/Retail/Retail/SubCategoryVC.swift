//
//  SubCategoryVC.swift
//  Retail
//
//  Created by Anand on 16/07/16.
//  Copyright © 2016 Anand. All rights reserved.
//

import UIKit
import Kingfisher
import TIPBadgeManager

class SubCategoryVC: UIViewController {
    private let useAutosizingCells = true
    private let cellIdentifier = "Category Cell"
    private let showBrowserSegueIdentifier = "detailsOfCategory"
    var arrayOfcategoryList:[AnyObject]!
    @IBOutlet weak var labelListTitle: UILabel!
    @IBOutlet weak var badgeView: UIView!
    var listTitle:String!
    
    
    @IBOutlet weak var tableCategoryList: UITableView!
    
    //MARK: - Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableCategoryList.estimatedRowHeight = 370
        tableCategoryList.rowHeight = UITableViewAutomaticDimension
    }
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        labelListTitle.text = listTitle
        
        badgeVal = DataManager().fetchData()!.count
        if badgeVal == 0 {
            badgeView.hidden = true
        }else{
            badgeView.hidden = false
            TIPBadgeManager.sharedInstance.addBadgeSuperview("someViewName", view: badgeView)
            TIPBadgeManager.sharedInstance.setBadgeValue("someViewName", value: badgeVal)
        }
        
        
    }
    
    @IBAction func actionBack(sender: AnyObject) {
        self.navigationController?.popViewControllerAnimated(true)
    }
    
    //MARK: - Navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if segue.identifier == showBrowserSegueIdentifier {
            if let selectedRow = tableCategoryList.indexPathForSelectedRow {
                let category = segue.destinationViewController as! DetailsVC
                category.details = arrayOfcategoryList[selectedRow.row] as? [String : AnyObject]
                
            }
        }
    }

}

extension SubCategoryVC: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrayOfcategoryList.count
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier(cellIdentifier, forIndexPath: indexPath) as! SubCategoryCell
        let json: [String: AnyObject] = arrayOfcategoryList[indexPath.row] as! [String : AnyObject]
        
        cell.productTitle.text = json["name"] as? String
        cell.productImage.kf_setImageWithURL(NSURL(string:(json["image"] as? String)!)!)
        cell.productImage.kf_showIndicatorWhenLoading = true
        cell.productPrice.text = "Rs. \((json["price"] as? String)!)"
        cell.productRating.text = json["rating"] as? String
        
        return cell
    }
    
}
