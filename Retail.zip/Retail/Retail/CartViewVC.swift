//
//  CartViewVC.swift
//  Retail
//
//  Created by Anand on 16/07/16.
//  Copyright © 2016 Anand. All rights reserved.
//

import UIKit
import Kingfisher
import CoreData

class CartViewVC: UIViewController {

    private let useAutosizingCells = true
    private let cellIdentifier = "Cart Cell"
    private let showBrowserSegueIdentifier = "detailsOfCategory"

    @IBOutlet weak var labelListTitle: UILabel!
    @IBOutlet weak var labelTotalAmount: UILabel!
     @IBOutlet weak var tableCartList: UITableView!
    
    
    var product = [NSManagedObject]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
 
    }

    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
       product = DataManager().fetchData()!
       totalAmount()
    }
    
    //MARK: - Total Amount
    func totalAmount(){
        var amount:Int = 0
        for price in product {
           amount += Int((price.valueForKey("price") as? String)!)!
        }
        print(amount)
        
        labelTotalAmount.text = "Rs." + String(amount)
    }
    
    @IBAction func actionCloseView(sender: AnyObject) {
        self.dismissViewControllerAnimated(true, completion: nil)
    }
    
    //MARK: - Remove from cart Product
    @IBAction func actionRemoveFromCart(sender: UIButton) {
        let json = product[sender.tag]
        product.removeAtIndex(sender.tag)
        DataManager().deleteEvent(json)
        tableCartList.reloadData()
        totalAmount()
    }
    
    @IBAction func actionPlaceOrder(sender: UIButton) {
        showAlertWith("Place order now available right now.")
    }
    
    //MARK: - Alert View
    func showAlertWith(message: String){
        let alert = UIAlertController(title: "Alert", message: message, preferredStyle: UIAlertControllerStyle.Alert)
        alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.Default, handler: nil))
        self.presentViewController(alert, animated: true, completion: nil)
    }
}

extension CartViewVC: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return product.count
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier(cellIdentifier, forIndexPath: indexPath) as! CartCell
        let json = product[indexPath.row]
        
        cell.labelTitle.text = json.valueForKey("productName") as? String
        cell.lablePrice.text = "Rs. \((json.valueForKey("price") as? String)!)"
        cell.productImage.kf_setImageWithURL(NSURL(string:(json.valueForKey("productImage") as? String)!)!)
        //cell.priceQty.text = json.valueForKey("qty") as? String
        cell.priceQty.hidden = true
        cell.buttonPlaceOrder.tag = indexPath.row
        cell.buttonRemoveFromCart.tag = indexPath.row
        
        return cell
    }
    
}
