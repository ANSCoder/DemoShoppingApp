//
//  DataManager.swift
//  Retail
//
//  Created by Anand on 16/07/16.
//  Copyright © 2016 Anand. All rights reserved.
//

import UIKit
import CoreData

var badgeVal : Int = 0
struct DataManager {

    var product = [NSManagedObject]()
    
    //1
    static let appDelegate = UIApplication.sharedApplication().delegate as! AppDelegate
    
    //MARK: - Fetch Cart details
    func fetchData() -> [NSManagedObject]? {
        //1
        let appDelegate =
            UIApplication.sharedApplication().delegate as! AppDelegate
        
        let managedContext = appDelegate.managedObjectContext
        
        //2
        let fetchRequest = NSFetchRequest(entityName: "Cart")
        
        //3
        do {
            let results =
                try managedContext.executeFetchRequest(fetchRequest)
            return results as? [NSManagedObject]
            
        } catch let error as NSError {
            print("Could not fetch \(error), \(error.userInfo)")
        }
        
        return nil
    }

    
    //MARK: - Save Data to Cart
    static func addToCart(name: String, image: String, price: String, qty: String) {
        
        let managedContext = appDelegate.managedObjectContext
        
        //2
        let entity =  NSEntityDescription.entityForName("Cart",
                                                        inManagedObjectContext:managedContext)
        
        let person = NSManagedObject(entity: entity!,
                                     insertIntoManagedObjectContext: managedContext)
        
        //3
        person.setValue(name, forKey: "productName")
        person.setValue(image, forKey: "productImage")
        person.setValue(price, forKey: "price")
        person.setValue(qty, forKey: "qty")
        
        //4
        do {
            try managedContext.save()
            //5
            print("Data Saved successfully.")
        } catch let error as NSError  {
            print("Could not save \(error), \(error.userInfo)")
        }

    }
    
    //MARK: - Delete Cart details
    func deleteEvent(name: AnyObject) {
        //Delete event item from persistance layer
        //1
        let appDelegate =
            UIApplication.sharedApplication().delegate as! AppDelegate
        
        let managedContext = appDelegate.managedObjectContext
        
        //3
        managedContext.deleteObject(name as! NSManagedObject)
        
        //3
        do {
            try managedContext.save()
            print("Data Delete Successfully.")
        } catch let error as NSError  {
            print("Could not save \(error), \(error.userInfo)")
        }
        
    }
    
    //MARK: - Update Cart details
    func updateCart(name: String, image: String, price: String, qty: String, index:Int) {
       
        let person = product[index]
        person.setValue(name, forKey: "productName")
        person.setValue(image, forKey: "productImage")
        person.setValue(price, forKey: "price")
        person.setValue(qty, forKey: "qty")
        
        do {
            try person.managedObjectContext?.save()
            
        } catch {
            let saveError = error as NSError
            print(saveError)
        }
        
    }

}
