//
//  ProductListVC.swift
//  Retail
//
//  Created by Anand on 12/07/16.
//  Copyright © 2016 Anand. All rights reserved.
//

import UIKit
import TIPBadgeManager

class ProductListVC: UIViewController {
    
    private let useAutosizingCells = true
    private let cellIdentifier = "Product Cell"
    private let showBrowserSegueIdentifier = "ShowCategory"
    private let arrayOfproductList:[String] = ["Electronics", "Furniture"]
    
    @IBOutlet weak var badgeView: UIView!
    
    @IBOutlet weak var tableProductList: UITableView!
    
    //MARK: - Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if useAutosizingCells && tableProductList.respondsToSelector(Selector("layoutMargins")) {
            tableProductList.estimatedRowHeight = 88
            tableProductList.rowHeight = UITableViewAutomaticDimension
        }

    }
    
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        
        badgeVal = DataManager().fetchData()!.count
        if badgeVal == 0 {
            badgeView.hidden = true
        }else{
            badgeView.hidden = false
            TIPBadgeManager.sharedInstance.addBadgeSuperview("someViewName", view: badgeView)
            TIPBadgeManager.sharedInstance.setBadgeValue("someViewName", value: badgeVal)
        }

    }
    
    //MARK: - Navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if segue.identifier == showBrowserSegueIdentifier {
            if let selectedRow = tableProductList.indexPathForSelectedRow {
                let category = segue.destinationViewController as! CategoryVC
                category.categoryType = selectedRow.row
            }
        }
    }
}

extension ProductListVC: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrayOfproductList.count
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier(cellIdentifier, forIndexPath: indexPath)
        let title = arrayOfproductList[indexPath.row]
        cell.textLabel?.text = title
        cell.imageView?.image = UIImage(named: title)
        
        if useAutosizingCells && tableView.respondsToSelector(Selector("layoutMargins")) {
            cell.textLabel?.numberOfLines = 0
            cell.detailTextLabel?.numberOfLines = 0
        }
        
        return cell
    }

}

