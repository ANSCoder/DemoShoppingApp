//
//  DetailsVC.swift
//  Retail
//
//  Created by Anand on 12/07/16.
//  Copyright © 2016 Anand. All rights reserved.
//

import UIKit

var descriptions:String?
var keyFeatures:String?

class DetailsVC: UIViewController {

    @IBOutlet weak var productImage: UIImageView!
    @IBOutlet weak var productTitle: UILabel!
    @IBOutlet weak var productPrice: UILabel!
    @IBOutlet weak var productDescription: UILabel!
    @IBOutlet weak var productSpecifications: UILabel!
    
    
    
    var details: [String: AnyObject]?
    
    //MARK: - Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        productTitle.text = details!["name"] as? String
        productImage.kf_setImageWithURL(NSURL(string:(details!["image"] as? String)!)!)
        productImage.kf_showIndicatorWhenLoading = true
        productPrice.text = details!["price"] as? String
        productDescription.text = descriptions
        productSpecifications.text = keyFeatures

    }

    //MARK: - Button Action
    @IBAction func actionAddtoCart(sender: AnyObject) {
        DataManager.addToCart((details!["name"] as? String)!, image: (details!["image"] as? String)!, price: (details!["price"] as? String)!, qty: "1")
        showAlertWith("Product successfully added to your cart.")
    }
    
    @IBAction func actionBuyNow(sender: AnyObject) {
        showAlertWith("Product out of stock right now.")
    }
    
    @IBAction func actionCloseView(sender: AnyObject) {
        self.dismissViewControllerAnimated(true, completion: nil)
    }

    //MARK: - Alert View
    func showAlertWith(message: String){
        let alert = UIAlertController(title: "Alert", message: message, preferredStyle: UIAlertControllerStyle.Alert)
        alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.Default, handler: nil))
        self.presentViewController(alert, animated: true, completion: nil)
    }
    
}
