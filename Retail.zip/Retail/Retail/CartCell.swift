//
//  CartCell.swift
//  Retail
//
//  Created by Anand on 18/07/16.
//  Copyright © 2016 Anand. All rights reserved.
//

import UIKit

class CartCell: UITableViewCell {

    @IBOutlet weak var labelTitle: UILabel!
    @IBOutlet weak var lablePrice: UILabel!
    @IBOutlet weak var productImage: UIImageView!
    @IBOutlet weak var priceQty: UILabel!
    @IBOutlet weak var buttonRemoveFromCart: UIButton!
    @IBOutlet weak var buttonPlaceOrder: UIButton!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
