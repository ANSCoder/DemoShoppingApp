//
//  CategoryVC.swift
//  Retail
//
//  Created by Anand on 18/07/16.
//  Copyright © 2016 Anand. All rights reserved.
//

import UIKit
import TIPBadgeManager

class CategoryVC: UIViewController {
    
    private let useAutosizingCells = true
    private let cellIdentifier = "Category Cell"
    private let showBrowserSegueIdentifier = "ShowSubCategory"
    private var arrayOfCategoryList = [AnyObject]()
    @IBOutlet weak var tableCategoryList: UITableView!
    var categoryType:Int?
    @IBOutlet weak var badgeView: UIView!
    
    enum category:Int {
        case electronics = 0
        case furniture = 1
    }
    
    enum source: String {
        case microwave = "Microwave oven"
        case television = "Television"
        case vaccume = "Vacuum Cleaner"
        case table = "Table"
        case chair = "Chair"
        case almirah = "Almirah"
    }
    
    //MARK: - Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()

        if useAutosizingCells && tableCategoryList.respondsToSelector(Selector("layoutMargins")) {
            tableCategoryList.estimatedRowHeight = 88
            tableCategoryList.rowHeight = UITableViewAutomaticDimension
        }

    }
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        
        badgeVal = DataManager().fetchData()!.count
        if badgeVal == 0 {
            badgeView.hidden = true
        }else{
            badgeView.hidden = false
            TIPBadgeManager.sharedInstance.addBadgeSuperview("someViewName", view: badgeView)
            TIPBadgeManager.sharedInstance.setBadgeValue("someViewName", value: badgeVal)
        }

        
        arrayOfCategoryList = []
        
        switch categoryType! {
        case category.electronics.rawValue:
            arrayOfCategoryList = ["Microwave oven", "Television", "Vacuum Cleaner"]
        case category.furniture.rawValue:
            arrayOfCategoryList = ["Table", "Chair", "Almirah"]
        default:break;
        }

    }

    @IBAction func actionBack(sender: AnyObject) {
        self.navigationController?.popViewControllerAnimated(true)
    }
    
    //MARK: - Navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if segue.identifier == showBrowserSegueIdentifier {
            if let selectedRow = tableCategoryList.indexPathForSelectedRow {
                let category = segue.destinationViewController as! SubCategoryVC
                let sub:String = arrayOfCategoryList[selectedRow.row] as! String
                category.listTitle = sub
            
                switch sub {
                case source.microwave.rawValue:
                     category.arrayOfcategoryList = SourceData.microwave
                     descriptions = SourceData.descriptionMicrowave
                     keyFeatures = SourceData.specificationMicrowave
                case source.television.rawValue:
                     category.arrayOfcategoryList = SourceData.television
                     descriptions = SourceData.descriptionTelevision
                     keyFeatures = SourceData.specificationTelevision
                case source.vaccume.rawValue:
                     category.arrayOfcategoryList = SourceData.vacuumCleaner
                     descriptions = SourceData.descriptionVacuumCleaner
                     keyFeatures = SourceData.specificationVacuumCleaner
                case source.table.rawValue:
                     category.arrayOfcategoryList = SourceData.table
                     descriptions = SourceData.descriptionTable
                     keyFeatures = SourceData.specificationTable
                case source.chair.rawValue:
                     category.arrayOfcategoryList = SourceData.chair
                     descriptions = SourceData.descriptionchair
                     keyFeatures = SourceData.specificationChair
                case source.almirah.rawValue:
                     category.arrayOfcategoryList = SourceData.almirah
                     descriptions = SourceData.descriptionAlmirah
                     keyFeatures = SourceData.specificationAlmirah
                default:break;
                }
            }
        }
    }
    
}

extension CategoryVC: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrayOfCategoryList.count
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier(cellIdentifier, forIndexPath: indexPath)
        let title = arrayOfCategoryList[indexPath.row]
        cell.textLabel?.text = title as? String
        
        if useAutosizingCells && tableView.respondsToSelector(Selector("layoutMargins")) {
            cell.textLabel?.numberOfLines = 0
            cell.detailTextLabel?.numberOfLines = 0
        }
        
        return cell
    }
    
}

