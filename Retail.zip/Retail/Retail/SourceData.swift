//
//  SourceData.swift
//  Retail
//
//  Created by Anand on 18/07/16.
//  Copyright © 2016 Anand. All rights reserved.
//

import UIKit

struct SourceData {

    static var microwave:[AnyObject] = [["name":"IFB 23 L Convection Microwave Oven (23SC3, Silver)", "image":"http://img5a.flixcart.com/image/microwave-new/3/w/y/ifb-23sc3-400x400-imaek9ufkvaedfqc.jpeg", "price": "9190", "rating": "4.3"], ["name": "Electrolux 23 L Convection Microwave Oven(C23J101.BB-CG, Black)", "image":"http://img5a.flixcart.com/image/microwave-new/z/z/n/electrolux-c23j101-bb-cg-400x400-imae4ty4ukf2ujz5.jpeg", "price": "7690", "rating": "4.4"], ["name": "LG 28 L Convection Microwave Oven(MC2883SMP, Silver)", "image":"http://img6a.flixcart.com/image/microwave-new/e/z/z/lg-mc2883smp-400x400-imadwr9wkfequmeg.jpeg", "price": "7690", "rating": "4.8"]]
    
    static var television:[AnyObject] = [["name":"Vu 80cm (32) HD Ready Smart LED TV(2 X HDMI, 2 X USB)", "image":"http://img6a.flixcart.com/image/television/n/g/n/vu-32d6475-hd-smart-400x400-imaeghrkgqtg4yut.jpeg", "price": "12190", "rating": "4.3"], ["name": "Vu 127cm (50) Ultra HD (4K) Smart LED TV(4 X HDMI, 3 X USB)", "image":"http://img6a.flixcart.com/image/television/p/z/a/vu-ltdn50k310x3d-400x400-imaedhsqzw5yqzpg.jpeg", "price": "23690", "rating": "4.4"], ["name": "Vu 80cm (32) HD Ready Smart LED TV(3 X HDMI, 3 X USB)", "image":"http://img6a.flixcart.com/image/television/m/f/x/vu-32s7545-400x400-imaedhtevh7kgzhf.jpeg", "price": "17690", "rating": "4.8"]]

    static var vacuumCleaner:[AnyObject] = [["name":"Eureka Forbes Easy Clean Plus Hand-held Vacuum Cleaner(Silver)", "image":"http://img5a.flixcart.com/image/vacuum-cleaner/e/e/g/eureka-forbes-easy-clean-easy-clean-plus-400x400-imae7dam5ey3vaeb.jpeg", "price": "2190", "rating": "4.3"], ["name": "Eureka Forbes Trendy Steel Dry Vacuum Cleaner(Steel Grey)", "image":"http://img6a.flixcart.com/image/vacuum-cleaner/s/c/j/eureka-forbes-trendy-steel-trendy-steel-400x400-imae7vashkfj2hgk.jpeg", "price": "6690", "rating": "4.4"], ["name": "Eureka Forbes Trendy Dx Wet & Dry Cleaner", "image":"http://img6a.flixcart.com/image/vacuum-cleaner/e/a/s/eureka-forbes-trendy-wet-dry-dx-trendy-dx-400x400-imaehsv3hxd6bpsr.jpeg", "price": "8990", "rating": "4.8"]]

    static var table:[AnyObject] = [["name":"HomeTown Will Engineered Wood Coffee Table(Finish Color - Brown)", "image":"http://img6a.flixcart.com/image/coffee-table/y/7/e/830008756001-mdf-hometown-white-400x400-imaebp6veufaw7px.jpeg", "price": "5660", "rating": "4.3"], ["name": "Nilkamal Orita Engineered Wood Office Table(Free Standing, Finish Color - Walnut)", "image":"http://img6a.flixcart.com/image/office-study-table/8/2/n/florita3fotpblkwnt-mdf-nilkamal-walnut-400x400-imaeeptqzwaasedm.jpeg", "price": "8990", "rating": "4.4"], ["name": "Durian ZEE/34486/B Glass Coffee Table(Finish Color - Green)", "image":"http://img6a.flixcart.com/image/coffee-table/y/f/y/zee-34486-b-tempered-glass-durian-green-400x400-imaefp4vfgc6xkkd.jpeg", "price": "11115", "rating": "4.6"]]
    
    static var chair:[AnyObject] = [["name":"Durian INTERIO-LB-BLACK Leatherette Office Chair(Brand Color - Black)", "image":"http://img5a.flixcart.com/image/office-study-chair/k/u/h/rich-37828-lb-a-leatherette-durian-400x400-imaeeg47kd5xyq5k.jpeg", "price": "11190", "rating": "4.3"], ["name": "Comfy Bean Bags XXXL Bean Bag Chair Cover (Without Filling)(Blue)", "image":"http://img6a.flixcart.com/image/bean-bag/t/s/f/nfbexarmchblu-cozy-bags-xxxl-400x400-imae24y9rg42htsg.jpeg", "price": "1190", "rating": "4.3"], ["name": "Cello Furniture Plastic Outdoor Chair(Finish Color - Brown)", "image":"http://img6a.flixcart.com/image/outdoor-chair/h/v/z/ecstasy-pp-cello-furniture-brown-400x400-imaefjnxy9wypmhg.jpeg", "price": "7890", "rating": "4.8"]]

    static var almirah:[AnyObject] = [["name":"Everything Imported Carbon Steel Collapsible Wardrobe(Finish Color - Black)", "image":"http://img5a.flixcart.com/image/collapsible-wardrobe/4/k/e/best-quality-4-feet-black-plaid-rack-shelf-almirah-carbon-steel-400x400-imae9khkdvh97w8f.jpeg", "price": "2390", "rating": "4.3"], ["name": "CbeeSo Carbon Steel Collapsible Wardrobe(Finish Color - Dark Maroon)", "image":"http://img6a.flixcart.com/image/collapsible-wardrobe/z/g/b/cb260-mild-steel-carbon-steel-cbeeso-dark-maroon-400x400-imae7fg4gehecbgj.jpeg", "price": "2890", "rating": "4.4"], ["name": "Spacewood Engineered Wood Free Standing Wardrobe(Finish Color - Natural Wenge Woodpore, 2 Door )", "image":"http://img5a.flixcart.com/image/wardrobe-closet/q/d/v/spacewood-arko-2-door-wardrobe-particle-board-spacewood-natural-400x400-imaefrq5cprdyzfh.jpeg", "price": "7690", "rating": "4.7"]]

    //MARK: - Description

    static var descriptionMicrowave:String = "Parts: Main Door/Door Plastic, The warranty does not cover accessories external to the product, The product is not used according to the instructions given in the instruction manual, Modification or alteration of any nature is made in the electrical circuitry/ or physical construction of the set, Site (premises where the product is kept) conditions that do not confirm to the recommended operating conditions of the machine, Defects due to cause beyond control like lightning, abnormal voltage, acts of God or while in transit to service centre or purchaser's residence."
    
    static var descriptionTelevision:String = "A+ Grade Panel \n Achromatic Panel \n USB Interface (Images) \n Still Image \n Movies Support in USB Mode \n Sports Details Sharpness \n Moisture Resistant + Dust Resistant Components \n Healthy from Inside \n Energy Efficient \n Table Top Mount \n Wall Mounting Brackets \n 1:"
    
    static var descriptionVacuumCleaner:String = "No Cord Tangles, Careful with Furniture, Superior Air Filtration, Variable Power Controls, Powerful Suction, Suction Opening, Blower Opening, 1 m Trendy Steel Extension Tube, Hose Length: 2 m, 2150 mm of water column."
    
    static var descriptionTable:String = "- The color of the product may vary slightly compared to the picture displayed on your screen. This is due to lighting, pixel quality and color settings \n - Please check the product's dimensions to ensure the product will fit in the desired location. Also, check if the product will fit through the entrance(s) and door(s) of the premises \n - Please expect an unevenness of up to 5 mm in the product due to differences in surfaces and floor levels \n - Flipkart, or the Seller delivering the product, will not take up any type of civil work, such as drilling holes in the wall to mount the product. The product will only be assembled in case carpentry assembly is required \n - In case the product appears to lack shine, wiping the surface with a cloth will help clear the surface of dust particles"
    
    static var descriptionchair:String = "- The color of the product may vary slightly compared to the picture displayed on your screen. This is due to lighting, pixel quality and color settings \n - Please check the product's dimensions to ensure the product will fit in the desired location. Also, check if the product will fit through the entrance(s) and door(s) of the premises \n - Please expect an unevenness of up to 5 mm in the product due to differences in surfaces and floor levels \n - Flipkart, or the Seller delivering the product, will not take up any type of civil work, such as drilling holes in the wall to mount the product. The product will only be assembled in case carpentry assembly is required \n - In case the product appears to lack shine, wiping the surface with a cloth will help clear the surface of dust particles"
    
    static var descriptionAlmirah:String = "The color of the product may vary slightly compared to the picture displayed on your screen. This is due to lighting, pixel quality and color settings. \n - Please check the product's dimensions to ensure the product will fit in the desired location. Also, check if the product will fit through the entrance(s) and door(s) of the premises. \n Please expect an unevenness of up to 5 mm in the product due to differences in surfaces and floor levels. \n - Flipkart, or the Seller delivering the product, will not take up any type of civil work, such as drilling holes in the wall to mount the product. The product will only be assembled in case carpentry assembly is required. \n - In case the product appears to lack shine, wiping the surface with a cloth will help clear the surface of dust particles"
    
    
    //MARK: - Specification
    static var specificationMicrowave:String = "Key Features of Morphy Richards 25 L Convection Microwave Oven \n Type : Convection \n Capacity : 25 L \n Control Type : Feather Touch \n Auto Cook Menu : 200 \n Cooking Modes : Convection, Grill."
    
    static var specificationTelevision:String = "Key Features of Vu 102cm (40) Full HD LED TV \n LED Display \n 102 cm (40) \n Full HD, 1920 x 1080 \n 2 x HDMI, 1 x USB \n Refresh Rate - 60"
    
    static var specificationVacuumCleaner:String = "Key Features of Eureka Forbes Easy Clean Plus Hand-held Vacuum Cleaner \n Hand-held Vacuum Cleaner \n 0.5L Dust Capacity \n Blower Feature \n 800 W Motor Power"
    
    static var specificationTable:String = "Key Features of HomeTown Will Engineered Wood Coffee Table \n # The glass top centre table has two surfaces which can be rotated to expand usable surface when required \n # The table is made of steel and MDF base for greater strength and sleek look . \n # MDF high gloss/ veneer + Glass"
    
    static var specificationChair:String = "Key Features of Durian Maestro-Hb-Black Fabric Office Chair \n ERGONOMIC DESIGNED \n Seat & Back : Black.Durable five star nylon base and castors \n Free delivery."
    
    static var specificationAlmirah:String = "Key Features of Everything Imported Carbon Steel Collapsible Wardrobe \n Portable Wardrobe Has Hanging Space And Shelves Which Are Very Practical And The Roll Down Cover Keeps The Dust Out"
    
}
